import React, { useState } from 'react';
import axios from 'axios';
import Login from './components/Login';
import Register from './components/Register';
import Home from './components/Home';
import Admin from './components/Admin';

axios.defaults.baseURL = 'http://localhost:5000/api';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [user, setUser] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-900 to-black text-white">
      <nav className="fixed top-0 w-full bg-black/50 backdrop-blur-md p-4 z-50">
        <div className="max-w-2xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-black bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
            🇲🇦 Instamaroc
          </h1>
          <div className="space-x-4">
            <button onClick={() => setCurrentPage('login')} className="px-4 py-2 bg-purple-600 rounded-xl hover:bg-purple-700">تسجيل دخول</button>
            <button onClick={() => setCurrentPage('register')} className="px-4 py-2 bg-pink-600 rounded-xl hover:bg-pink-700">تسجيل</button>
            <button onClick={() => setCurrentPage('admin')} className="px-4 py-2 bg-red-600 rounded-xl hover:bg-red-700">👑 Admin</button>
          </div>
        </div>
      </nav>

      <div className="pt-20 max-w-2xl mx-auto p-4">
        {currentPage === 'login' && <Login setCurrentPage={setCurrentPage} setUser={setUser} />}
        {currentPage === 'register' && <Register setCurrentPage={setCurrentPage} setUser={setUser} />}
        {currentPage === 'home' && <Home />}
        {currentPage === 'admin' && <Admin />}
      </div>
    </div>
  );
}

export default App;