import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Home = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axios.get('/posts').then(res => setPosts(res.data));
  }, []);

  return (
    <div>
      <div className="flex space-x-4 mb-8 overflow-x-auto pb-4 -mx-4 px-4">
        {['القصص', 'achraf_h', 'fatima_z', 'mohamed_k'].map((story, i) => (
          <div key={i} className="flex flex-col items-center space-y-1 p-2 hover:scale-110 transition-all">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-sm font-bold text-white">
              {story[0]}
            </div>
            <p className="text-xs text-gray-300">{story}</p>
          </div>
        ))}
      </div>

      {posts.map((post) => (
        <div key={post.id} className="bg-black/50 backdrop-blur-xl rounded-3xl p-6 mb-6 border border-purple-500/30">
          <div className="flex items-center space-x-3 mb-4">
            <img src={post.user.profilePic} className="w-12 h-12 rounded-full" />
            <div>
              <h3 className="font-bold">{post.user.username}</h3>
              <p className="text-sm text-gray-400">· دقيقة ·</p>
            </div>
          </div>
          
          <img src={post.image} className="w-full rounded-2xl mb-4 aspect-square object-cover" />
          
          <div className="space-y-3">
            <div className="flex space-x-4 text-2xl">
              <button>❤️</button>
              <button>💬</button>
              <button>📤</button>
            </div>
            <p className="font-bold">{post.likes.toLocaleString()} لايك</p>
            <p className="font-semibold">{post.user.username}</p>
            <p>{post.caption}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Home;