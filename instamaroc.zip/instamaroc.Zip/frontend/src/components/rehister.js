import React, { useState } from 'react';
import axios from 'axios';

const Register = ({ setCurrentPage, setUser }) => {
  const [formData, setFormData] = useState({ username: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const res = await axios.post('/register', formData);
      localStorage.setItem('token', res.data.token);
      setUser(res.data.user);
      setCurrentPage('home');
    } catch (error) {
      alert('خطأ في التسجيل!');
    }
    
    setLoading(false);
  };

  return (
    <div className="max-w-md mx-auto bg-black/30 backdrop-blur-xl rounded-3xl p-8">
      <h2 className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
        إنشاء حساب جديد
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="اسم المستخدم"
          value={formData.username}
          onChange={(e) => setFormData({...formData, username: e.target.value})}
          className="w-full p-4 bg-black/50 border border-purple-500 rounded-2xl text-white placeholder-gray-400"
          required
        />
        <input
          type="email"
          placeholder="الإيميل"
          value={formData.email}
          onChange={(e) => setFormData({...formData, email: e.target.value})}
          className="w-full p-4 bg-black/50 border border-purple-500 rounded-2xl text-white placeholder-gray-400"
          required
        />
        <input
          type="password"
          placeholder="كلمة السر"
          value={formData.password}
          onChange={(e) => setFormData({...formData, password: e.target.value})}
          className="w-full p-4 bg-black/50 border border-purple-500 rounded-2xl text-white placeholder-gray-400"
          required
        />
        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 p-4 rounded-2xl font-bold text-lg hover:scale-105 transition-all disabled:opacity-50"
        >
          {loading ? 'جاري الإنشاء...' : 'إنشاء حساب'}
        </button>
      </form>
    </div>
  );
};

export default Register;