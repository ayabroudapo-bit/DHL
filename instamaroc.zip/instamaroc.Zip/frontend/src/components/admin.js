import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Admin = () => {
  const [adminToken, setAdminToken] = useState('');
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState({});
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (adminToken) {
      fetchAdminData();
    }
  }, [adminToken]);

  const loginAdmin = async () => {
    try {
      const res = await axios.post('/admin/login', { password: 'admin123' });
      setAdminToken(res.data.token);
      localStorage.setItem('adminToken', res.data.token);
    } catch (error) {
      alert('كلمة السر غلط!');
    }
  };

  const fetchAdminData = async () => {
    try {
      const [usersRes, statsRes] = await Promise.all([
        axios.get('/admin/users'),
        axios.get('/admin/stats')
      ]);
      setUsers(usersRes.data);
      setStats(statsRes.data);
    } catch (error) {
      console.error('خطأ في جلب البيانات');
    }
  };

  const banUser = async (userId) => {
    if (!confirm('هل أنت متأكد من حظر هاد المستخدم؟')) return;
    
    try {
      await axios.put(`/admin/users/${userId}/ban`);
      fetchAdminData();
    } catch (error) {
      alert('خطأ في الحظر');
    }
  };

  const unbanUser = async (userId) => {
    try {
      await axios.put(`/admin/users/${userId}/unban`);
      fetchAdminData();
    } catch (error) {
      alert('خطأ في إلغاء الحظر');
    }
  };

  const deleteUser = async (userId) => {
    if (!confirm('هل أنت متأكد من الحذف النهائي؟')) return;
    
    try {
      await axios.delete(`/admin/users/${userId}`);
      fetchAdminData();
    } catch (error) {
      alert('خطأ في الحذف');
    }
  };

  const massBan = async () => {
    if (selectedUsers.length === 0) return alert('اختر مستخدمين أولاً!');
    if (!confirm(`حظر ${selectedUsers.length} مستخدم؟`)) return;
    
    try {
      await axios.post('/admin/mass-ban', { userIds: selectedUsers });
      fetchAdminData();
      setSelectedUsers([]);
    } catch (error) {
      alert('خطأ في الحظر الجماعي');
    }
  };

  if (!adminToken) {
    return (
      <div className="max-w-md mx-auto bg-red-600/50 backdrop-blur-xl rounded-3xl p-12 text-center border-4 border-red-500/50">
        <h1 className="text-4xl font-black mb-8 text-white">🔐 لوحة التحكم</h1>
        <p className="text-xl mb-8 text-red-100">كلمة السر: <code className="bg-black px-3 py-1 rounded font-bold">admin123</code></p>
        <button 
          onClick={loginAdmin}
          className="px-12 py-4 bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-black text-xl rounded-3xl hover:scale-105 transition-all shadow-2xl"
        >
          👑 دخول الأدمن
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-5xl font-black bg-gradient-to-r from-red-500 via-purple-600 to-pink-500 bg-clip-text text-transparent mb-4">
          👑 لوحة التحكم الإدارية
        </h1>
        <button 
          onClick={() => {setAdminToken(''); localStorage.removeItem('adminToken');}}
          className="px-6 py-2 bg-gray-800 rounded-xl hover:bg-gray-700"
        >
          خروج
        </button>
      </div>

      {/* 📊 Stats */}
      <div className="grid grid-cols-4 gap-6 p-8 bg-gradient-to-r from-red-900/50 to-purple-900/50 rounded-3xl backdrop-blur-xl">
        <div className="text-center">
          <h3 className="text-3xl font-bold text-white">{stats.totalUsers || 0}</h3>
          <p className="text-gray-300">👥 إجمالي المستخدمين</p>
        </div>
        <div className="text-center">
          <h3 className="text-3xl font-bold text-red-400">{stats.bannedUsers || 0}</h3>
          <p className="text-gray-300">🚫 المحظورين</p>
        </div>
        <div className="text-center">
          <h3 className="text-3xl font-bold text-green-400">{stats.activeUsers || 0}</h3>
          <p className="text-gray-300">🔥 النشيطين اليوم</p>
        </div>
        <div className="text-center">
          <h3 className="text-3xl font-bold text-yellow-400">{stats.percentageBanned || 0}%</h3>
          <p className="text-gray-300">نسبة المحظورين</p>
        </div>
      </div>

      {/* 👥 Users Table */}
      <div className="bg-black/30 backdrop-blur-xl rounded-3xl p-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold text-white">👥 إدارة المستخدمين ({users.length})</h2>
          {selectedUsers.length > 0 && (
            <button
              onClick={massBan}
              className="bg-red-600 hover:bg-red-700 px-8 py-3 rounded-2xl font-bold text-lg transition-all"
            >
              🚫 حظر جماعي ({selectedUsers.length})
            </button>
          )}
        </div>

        <div className="max-h-96 overflow-y-auto space-y-3">
          {users.map((user) => (
            <div key={user._id} className="flex items-center justify-between p-4 bg-white/10 rounded-2xl hover:bg-white/20 transition-all">
              <div className="flex items-center space-x-4 flex-1">
                <input
                  type="checkbox"
                  checked={selectedUsers.includes(user._id)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedUsers([...selectedUsers, user._id]);
                    } else {
                      setSelectedUsers(selectedUsers.filter(id => id !== user._id));
                    }
                  }}
                  className="w-5 h-5 rounded text-purple-600"
                />
                <img src={user.profilePic} className="w-12 h-12 rounded-full" alt={user.username} />
                <div>
                  <h3 className="font-bold text-white">{user.username}</h3>
                  <p className="text-gray-400 text-sm">{user.email}</p>
                  <p className="text-xs text-gray-500">
                    متابعين: {user.followers?.length || 0} | منشورات: {user.posts?.length || 0}
                  </p>
                </div>
              </div>
              
              <div className="flex space-x-2">
                {user.banned ? (
                  <button
                    onClick={() => unbanUser(user._id)}
                    className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-xl font-medium transition-all"
                  >
                    ✅ إلغاء الحظر
                  </button>
                ) : (
                  <button
                    onClick={() => banUser(user._id)}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-xl font-medium transition-all"
                  >
                    🚫 حظر
                  </button>
                )}
                <button
                  onClick={() => deleteUser(user._id)}
                  className="px-4 py-2 bg-gray-800 hover:bg-gray-700 border rounded-xl font-medium transition-all"
                >
                  🗑️ حذف
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Admin;