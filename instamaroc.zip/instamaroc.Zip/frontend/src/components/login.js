import React, { useState } from 'react';
import axios from 'axios';

const Login = ({ setCurrentPage, setUser }) => {
  const [formData, setFormData] = useState({ email: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/login', formData);
      localStorage.setItem('token', res.data.token);
      setUser(res.data.user);
      setCurrentPage('home');
    } catch (error) {
      alert('بيانات غلط!');
    }
  };

  return (
    <div className="max-w-md mx-auto bg-black/30 backdrop-blur-xl rounded-3xl p-8">
      <h2 className="text-3xl font-bold text-center mb-8 text-white">تسجيل الدخول</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="email"
          placeholder="الإيميل"
          value={formData.email}
          onChange={(e) => setFormData({...formData, email: e.target.value})}
          className="w-full p-4 bg-black/50 border border-purple-500 rounded-2xl text-white"
          required
        />
        <input
          type="password"
          placeholder="كلمة السر"
          value={formData.password}
          onChange={(e) => setFormData({...formData, password: e.target.value})}
          className="w-full p-4 bg-black/50 border border-purple-500 rounded-2xl text-white"
          required
        />
        <button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-pink-600 p-4 rounded-2xl font-bold">
          دخول
        </button>
      </form>
    </div>
  );
};

export default Login;