require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('./models/User');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGODB_URI);

// 🔐 تسجيل
app.post('/api/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 12);
    
    const user = new User({
      username,
      email,
      password: hashedPassword,
      profilePic: `https://ui-avatars.com/api/?name=${username[0]}&background=6B46C1&color=fff`
    });
    
    await user.save();
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
    
    res.json({
      success: true,
      token,
      user: { id: user._id, username, email, profilePic: user.profilePic }
    });
  } catch (error) {
    res.status(400).json({ success: false, message: 'خطأ في التسجيل' });
  }
});

// 🚪 تسجيل الدخول
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    
    if (!user || !await bcrypt.compare(password, user.password)) {
      return res.status(400).json({ success: false, message: 'بيانات غلط' });
    }
    
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
    res.json({
      success: true,
      token,
      user: { id: user._id, username: user.username, profilePic: user.profilePic }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'خطأ السيرفر' });
  }
});

// 👥 جلب المستخدمين
app.get('/api/users', async (req, res) => {
  const users = await User.find({ banned: false }).select('username profilePic followers');
  res.json(users);
});

// 📸 منشورات وهمية
app.get('/api/posts', (req, res) => {
  res.json([
    {
      id: 1,
      user: { username: 'achraf_h', profilePic: 'https://ui-avatars.com/api/?name=A&background=6B46C1' },
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500',
      caption: 'مراكش الجميلة! #مراكش #مغرب 🇲🇦',
      likes: 1247,
      comments: 89
    },
    {
      id: 2,
      user: { username: 'fatima_z', profilePic: 'https://ui-avatars.com/api/?name=F&background=EC4899' },
      image: 'https://images.unsplash.com/photo-1574169208507-84376144848b?w=500',
      caption: 'كسكس مغربي أصلي! #كسكس #مطبخ_مغربي',
      likes: 856,
      comments: 45
    }
  ]);
});

// 👑 Admin Panel
app.post('/api/admin/login', (req, res) => {
  if (req.body.password === process.env.ADMIN_PASSWORD) {
    const token = jwt.sign({ role: 'admin' }, process.env.ADMIN_PASSWORD);
    res.json({ success: true, token });
  } else {
    res.status(401).json({ success: false });
  }
});

app.get('/api/admin/users', (req, res) => {
  User.find().then(users => res.json(users));
});

app.listen(5000, () => {
  console.log('🚀 Backend يشتغل على http://localhost:5000');
});